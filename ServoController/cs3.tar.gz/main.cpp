/* 
 * File:   main.cpp
 * Author: wessel
 *
 * Created on May 12, 2014, 9:44 AM
 */

#include "ServerSocket.h"
#include "SocketException.h"
#include <iostream>
#include <string>
#include <pthread.h>

void* serverThread(void* arg) {
    std::cout << "Server running...\n";

    try {
        // Create the socket
        ServerSocket server(30000);

        while (true) {

            ServerSocket new_sock;
            server.accept(new_sock);

            try {
                while (true) {
                    std::string data;
                    new_sock >> data;
                    std::cout << data << "\n";
                    new_sock << "Message received.";
                    //new_sock << data;
                }
            } catch (SocketException&) {
            }

        }
    } catch (SocketException& e) {
        std::cout << "Exception was caught:" << e.description() << "\nExiting.\n";
    }
}

int main(int argc, char** argv) {
    pthread_t ts;
    pthread_create(&ts, NULL, &serverThread, NULL);
    void* res;
    pthread_join(ts, &res);

    return 0;
}